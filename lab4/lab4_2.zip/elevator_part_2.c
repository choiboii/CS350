#include <stdio.h>
#include<stdlib.h>
#include <pthread.h>
#include "elevator.h"

//global variables:
Dllist list_of_people;
pthread_cond_t door_cond;

void initialize_simulation(Elevator_Simulation *es){
    list_of_people = new_dllist();
    pthread_cond_init(&door_cond, NULL);
    //add void pointer
    
}

void initialize_elevator(Elevator *e){
    //add void pointer
    
}

void initialize_person(Person *e){
    //add void pointer
}

void wait_for_elevator(Person *p){
    dll_append(list_of_people, new_jval_v(p));
    pthread_mutex_lock(p->lock);
    while(p->e == NULL){
        pthread_cond_signal(&door_cond);
        pthread_cond_wait(p->cond, p->lock);
    }
    pthread_mutex_unlock(p->lock);
    
    
}

void wait_to_get_off_elevator(Person *p){
    pthread_mutex_lock(p->lock);
    while(p->to != p->e->onfloor){
        pthread_cond_signal(&door_cond);
        pthread_cond_wait(p->cond, p->lock);
    }
    pthread_mutex_unlock(p->lock);
    
}

void person_done(Person *p){
    /* Dllist currentnode = list_of_people;
    Person * targetP = (Person *)currentnode->val;
    while(targetP != p){
        currentnode = currentnode->flink;
        targetP = (Person *)currentnode->val;
    }
    dll_delete_node(currentnode);*/
    pthread_cond_signal(p->cond);
}

void check_for_people_to_unload(){
    
}

void check_for_people_to_load(){
    
}

void move(Person * p){
    
}

void *elevator(void *arg){
    Person * p = (Person *)arg;
    Elevator * e = p->e;
    while(!(list_of_people->flink != list_of_people->blink)){
        pthread_cond_wait(e->cond, e->lock);
    }
    while(list_of_people->flink != list_of_people->blink){ //while the global list is not empty
        move_to_floor(p->e, p->from);
        open_door(e);
        get_on_elevator(p);
        close_door(e);
        move_to_floor(e, p->to);
        open_door(e);
        get_off_elevator(p);
        close_door(e);
    }
    return NULL;
}