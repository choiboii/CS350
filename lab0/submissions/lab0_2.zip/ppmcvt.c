#include "pbm.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

//helper functions:
double average_rgb(PPMImage * ppm, unsigned int h, unsigned int w){
    int sum = ppm->pixmap[0][h][w] + ppm->pixmap[0][h][w] + ppm->pixmap[0][h][w];
    double average = (double)sum / 3;

    return average;
}


/* 
* Possible inputs:
* -b  convert input file to a Portable Bitmap (PBM) file. (DEFAULT)
* -g: convert input file to a Portable Gray Map (PGM) file using the specified max grayscale pixel value [1-65535].
* -i: isolate the specified RGB channel. Valid channels are “red”, “green”, or “blue”.
* -r: remove the specified RGB channel. Valid channels are “red”, “green”, or “blue”.
* -s  apply a sepia transformation
* -m  vertically mirror the first half of the image to the second half
* -t: reduce the input image to a thumbnail based on the given scaling factor [1-8].
* -n: tile thumbnails of the input image based on the given scaling factor [1-8].
* -o: write output image to the specified file. Existent output files will be overwritten.
*/

// -b: convert input file to a Portable Bitmap (PBM) file. (DEFAULT) 
void * convert_to_PBMImage (const char * infilename, const char * outfilename){
    PPMImage * ppm = read_ppmfile(infilename);
    unsigned int h = ppm->height;
    unsigned int w = ppm->width;
    unsigned int max = ppm->max;

    PBMImage * pbm = new_pbmimage(w, h);

    for(int i = 0; i < h; i++){
        for(int j = 0; j < w; j++){
            pbm->pixmap[i][j] = (int)average_rgb(ppm, i, h) < (max / 2);
        }
    }

    write_pbmfile(pbm, outfilename);

    del_pbmimage(pbm);
}

// -g: convert input file to a Portable Gray Map (PGM) file using the specified max grayscale pixel value [1-65535].
void * convert_to_PGMImage (const char * infilename, const char * outfilename, const int * pixel_value){
    PPMImage * ppm = read_ppmfile(infilename);
    unsigned int h = ppm->height;
    unsigned int w = ppm->width;
    unsigned int max = ppm->max;

    PGMImage * pgm = new_pgmimage(w, h, *pixel_value);

    for(int i = 0; i < h; i++){
        for(int j = 0; j < w; j++){
            pgm->pixmap[i][j] = (int)(average_rgb(ppm, i, h) / max * (*pixel_value));
        }
    }

    write_pgmfile(pgm, outfilename);

    del_pgmimage(pgm);
}

// -i: isolate the specified RGB channel. Valid channels are “red”, “green”, or “blue”.
void * isolate_RGB_channel (const char * infilename, const char * outfilename, const char * channel){
    PPMImage * ppm = read_ppmfile(infilename);
    unsigned int h = ppm->height;
    unsigned int w = ppm->width;

    if(strcmp(channel, "red") == 0){
        for(int i = 0; i < h; i++){
            for(int j = 0; j < w; j++){
                ppm->pixmap[1][i][j] = 0;
                ppm->pixmap[2][i][j] = 0;
            }
        }
    }
    else if(strcmp(channel, "green") == 0){
        for(int i = 0; i < h; i++){
            for(int j = 0; j < w; j++){
                ppm->pixmap[0][i][j] = 0;
                ppm->pixmap[2][i][j] = 0;
            }
        }
    }
    else { //blue
        for(int i = 0; i < h; i++){
            for(int j = 0; j < w; j++){
                ppm->pixmap[0][i][j] = 0;
                ppm->pixmap[1][i][j] = 0;
            }
        }
    }
}

// -r: remove the specified RGB channel. Valid channels are “red”, “green”, or “blue”.
void * remove_RGB_channel (const char * infilename, const char * outfilename, const char * channel){
    PPMImage * ppm = read_ppmfile(infilename);
    unsigned int h = ppm->height;
    unsigned int w = ppm->width;

    if(strcmp(channel, "red") == 0){
        for(int i = 0; i < h; i++){
            for(int j = 0; j < w; j++){
                ppm->pixmap[0][i][j] = 0;
            }
        }
    }
    else if(strcmp(channel, "green") == 0){
        for(int i = 0; i < h; i++){
            for(int j = 0; j < w; j++){
                ppm->pixmap[1][i][j] = 0;
            }
        }
    }
    else{ //blue
        for(int i = 0; i < h; i++){
            for(int j = 0; j < w; j++){
                ppm->pixmap[2][i][j] = 0;
            }
        }
    }
}

// -s  apply a sepia transformation
void * sepia_transformation (const char * infilename, const char * outfilename){
    PPMImage * in_ppm = read_ppmfile(infilename);
    unsigned int h = in_ppm->height;
    unsigned int w = in_ppm->width;
    unsigned int max = in_ppm->max;
    double old_red, old_green, old_blue;

    PPMImage * out_ppm = new_ppmimage(w, h, max);
    unsigned int new_red, new_green, new_blue;

    for(int i = 0; i < h; i++){
        for(int j = 0; j < w; j++){
            old_red = (double)(in_ppm->pixmap[0][i][j]);
            old_green = (double)(in_ppm->pixmap[1][i][j]);
            old_blue = (double)(in_ppm->pixmap[2][i][j]);

            new_red = (int)(.393 * old_red + .769 * old_green + .189 * old_blue);
            new_green = (int)(.349 * old_red + .686 * old_green + .168 * old_blue);
            new_blue = (int)(.272 * old_red + .534 * old_green + .131 * old_blue);

            out_ppm->pixmap[0][i][j] = new_red;
            out_ppm->pixmap[1][i][j] = new_green;
            out_ppm->pixmap[2][i][j] = new_blue;
        }
    }

    write_ppmfile(out_ppm, outfilename);

    del_ppmimage(out_ppm);
}

// -m vertically mirror the first half of the image to the second half
void * mirror_image (const char * infilename, const char * outfilename){
    PPMImage * in_ppm = read_ppmfile(infilename);
    unsigned int h = in_ppm->height;
    unsigned int w = in_ppm->width;
    unsigned int max = in_ppm->max;

    PPMImage * out_ppm = new_ppmimage(w, h, max);

    for(int i = 0; i < h; i++){
        for(int j = 0; j < w/2; j++){
            out_ppm->pixmap[0][i][j] = in_ppm->pixmap[0][i][j];
            out_ppm->pixmap[0][i][w - (j + 1)] = in_ppm->pixmap[0][i][j];
            out_ppm->pixmap[1][i][j] = in_ppm->pixmap[1][i][j];
            out_ppm->pixmap[1][i][w - (j + 1)] = in_ppm->pixmap[1][i][j];
            out_ppm->pixmap[2][i][j] = in_ppm->pixmap[2][i][j];
            out_ppm->pixmap[2][i][w - (j + 1)] = in_ppm->pixmap[2][i][j];
        }
    }

    write_ppmfile(out_ppm, outfilename);

    del_ppmimage(out_ppm);
}

// -t: reduce the input image to a thumbnail based on the given scaling factor [1-8].
void * thumbnail_image (const char * infilename, const char * outfilename, const int * scale_factor){
    PPMImage * in_ppm = read_ppmfile(infilename);
    unsigned int h = in_ppm->height;
    unsigned int w = in_ppm->width;
    unsigned int max = in_ppm->max;

    unsigned int n = *scale_factor;

    PPMImage * out_ppm = new_ppmimage(w/n, h/n, max);

    for(int i = 0; i < h/n; i++){
        for(int j = 0; j < w/n; j++){
            out_ppm->pixmap[0][i][j] = in_ppm->pixmap[0][i*n][j*n];
            out_ppm->pixmap[1][i][j] = in_ppm->pixmap[1][i*n][j*n];
            out_ppm->pixmap[2][i][j] = in_ppm->pixmap[2][i*n][j*n];
        }
    }

    write_ppmfile(out_ppm, outfilename);

    del_ppmimage(out_ppm);
}

// -n: tile thumbnails of the input image based on the given scaling factor [1-8].
void * tile_thumbnail_image (const char * infilename, const char * outfilename, const int * scale_factor){
    PPMImage * in_ppm = read_ppmfile(infilename);
    unsigned int h = in_ppm->height;
    unsigned int w = in_ppm->width;
    unsigned int max = in_ppm->max;

    unsigned int n = *scale_factor;

    PPMImage * out_ppm = new_ppmimage(w, h, max);

    for(int i = 0; i < n; i++){
        for(int j = 0; j < h/n; j++){
            for(int k = 0; k < w/n; k++){
                out_ppm->pixmap[0][j*(i+1)][k*(i+1)] = in_ppm->pixmap[0][j*n][k*n];
                out_ppm->pixmap[1][j*(i+1)][k*(i+1)] = in_ppm->pixmap[1][j*n][k*n];
                out_ppm->pixmap[2][j*(i+1)][k*(i+1)] = in_ppm->pixmap[2][j*n][k*n];
            }
        }
    }

    write_ppmfile(out_ppm, outfilename);

    del_ppmimage(out_ppm);
}

void * do_transformation(options * command){
    char * mode = command->mode;
    if(command->arg != NULL){
        int * arg = command->arg;
    }
    char * infilename = command->infile_name;
    char * outfilename = command->outfile_name;

    if(mode == 'b'){
        convert_to_PBMImage(infilename, outfilename);
    }
    if(mode == 'g'){
        convert_to_PGMImage(infilename, outfilename, arg);
    }
    if(mode == 'i'){
        isolate_RGB_channel(infilename, outfile, arg);
    }
    if(mode == 'r'){
        remove_RGB_channel(infilename, outfilename, arg);
    }
    if(mode == 's'){
        sepia_transformation(infilename, outfilename);
    }
    if(mode == 'm'){
        mirror_image(infilename, outfilename);
    }
    if(mode == 't'){
        thumbnail_image(infilename, outfilename, arg);
    }
    if(mode == 'n'){
        tile_thumbnail_image(infilename, outfilename, arg);
    }
}


//Options struct for processing command line
typedef struct{
    char mode, infile_name, outfile_name;
    int arg;
} Options;

int main( int argc, char *argv[] ){

    Options * commands;
    int i = 0;
    int c;

    //process command line:
    while ((c = getopt(argc, argv, "g:i:r:smt:n:o:")) != -1){
        switch (c){
        case 'g':
            if(commands->mode != NULL){
                fprintf(stderr, "Error: Multiple transformations specified\n");
                exit(1);
            }
            if(optarg > 65535){
                fprintf(stderr, "Error: Invalid max grayscale pixel value: %s; must be less than 65,536\n");
                exit(1);
            }
            commands->mode = argv[i];
            commands->arg = optarg;
            break;
        case 'i':
            if(commands->mode != NULL){
                fprintf(stderr, "Error: Multiple transformations specified\n");
                exit(1);
            }
            commands->mode = argv[i];
            if(optarg != "red" || optarg != "green" || optarg != "blue"){
                fprintf(stderr, "Error: Invalid channel specification: (%s); should be 'red', 'green' or 'blue'\n", optarg);
                exit(1);
            }
            commands->arg = strol(optarg);
            break;
        case 'r':
            if(commands->mode != NULL){
                fprintf(stderr, "Error: Multiple transformations specified\n"); 
                exit(1);
            }
            if(optarg != "red" || optarg != "green" || optarg != "blue"){
                fprintf(stderr, "Error: Invalid channel specification: (%s); should be 'red', 'green' or 'blue'\n", optarg);
                exit(1);
            }
            commands->mode = argv[i];
            commands->arg = strol(optarg);
            break;
        case 's':
            if(commands->mode != NULL){
                fprintf(stderr, "Error: Multiple transformations specified\n");  
                exit(1);
            }
            commands->mode = argv[i];
            break;
        case 'm':
            if(commands->mode != NULL){
                fprintf(stderr, "Error: Multiple transformations specified\n"); 
                exit(1);
            }
            commands->mode = argv[i];
            break;   
        case 't':
            if(commands->mode != NULL){
                fprintf(stderr, "Error: Multiple transformations specified\n"); 
                exit(1);
            }
            if(optarg > 8){
                fprintf(stderr, "Error: Invalid scale factor: %d; must be 1-8\n", optarg);
                exit(1);
            }
            commands->mode = argv[i];
            commands->arg = optarg;
            break;
        case 'n':
            if(commands->mode != NULL){
                fprintf(stderr, "Error: Multiple transformations specified\n"); 
                exit(1);
            }
            if(optarg > 8){
                fprintf(stderr, "Error: Invalid scale factor: %d; must be 1-8\n", optarg);
                exit(1);
            }
            commands->mode = argv[i];
            commands->arg = optarg;
            break;
        case 'o':
            commands->outfile_name = optarg;
            break;
        case '?':
            if(strstr(argv[i], ".ppm") != NULL){
                commands->infile_name = argv[i];
            }
            else{
                fprintf(stderr, "Usage: ppmcvt [-bgirsmtno] [FILE]\n");
                exit(1);
            }
            break;
        }
        i++;
    }

    //check options struct:

    if(commands->mode == NULL){
        commands->mode = 'b';
    }
    if(commands->infile_name == NULL){
        fprintf(stderr, "Error: No input file specified\n" );
        exit(1);
    }
    if(commands->outfile_name == NULL){
        fprintf(stderr, "Error: No output file specified\n" );
        exit(1);
    }

    do_transformation(commands);

    return 0;
}