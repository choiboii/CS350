//
//  my_malloc.c
//  Lab1: Malloc
//

#include "my_malloc.h"
#include <unistd.h>

MyErrorNo my_errno=MYNOERROR;
static int MAGICNUMBER = 123456;
FreeListNode first_node;

void *my_malloc(uint32_t size){
    static uint32_t * free_heap_begin;
    uint32_t * ptr = free_heap_begin;
    uint32_t * heap_end = sbrk(0);

    size += 8;  //bytes for bookkeeping
    if(size % 8 != 0){ //make chunk size divisble by 8
        size += (8 - (size % 8));
    }

    uint32_t minimum_chunk_size = 16; //set minimum chunk size
    if(size > 16){
        minimum_chunk_size = size;
    }
    
    //find chunk from free list
    FreeListNode free_chunk_ptr = free_list_begin();

    //if freelist null -> call sbrk
    if(free_chunk_ptr == NULL){
        if(size > 8192){
            sbrk(size);
        }
        else{
            sbrk(8192);
        }
        free_heap_begin += size;
    }
    else{
        uint32_t usable_chunk = 1;

        //check the first node
        if(free_chunk_ptr->size >= size){
            usable_chunk = 0;
            ptr = (uint32_t*)free_chunk_ptr;
        }
        //traverse free list to find usable chunk
        while(free_chunk_ptr->flink != NULL || usable_chunk == 1){
            if(free_chunk_ptr->size >= size){
                usable_chunk = 0;
                ptr = (uint32_t*)free_chunk_ptr;
                break;
            }
            free_chunk_ptr = free_chunk_ptr->flink;
        }
        //if no usable chunks found, create new chunk at end of heap
        if(usable_chunk == 1){
            if(size > 8192){
                sbrk(size);
            }
            else{
                sbrk(8192);
            }
            free_heap_begin += size;
        }
    }

    //oversized chunk: if chunk in free list > memory requested
    if(size / 2 > minimum_chunk_size){
        //split chunk
        size = size / 2; //split the two chunks
        FreeListNode split_chunk_ptr;
        split_chunk_ptr->size = size;
        free_chunk_ptr->flink = split_chunk_ptr;   //add a pointer from the chunk to the split chunk, as they are adjacent
        //split_chunk->flink = NULL;
    }

    //if chunk_begin is still null:
    if(ptr == NULL){
        my_errno = MYENOMEM;
        return NULL;
    }
    
    //initialize bookkeeping variables in the header
    *((uint32_t*)ptr) = size;
    *((uint32_t*)ptr + 1) = MAGICNUMBER; //MAGICNUMBER indicates that the chunk is malloc'd

    return (uint32_t*)ptr + 2;
}
      
void my_free(void *ptr){
    //check if chunk is malloc'd
    if(ptr == NULL || *((uint32_t*)ptr + 1) != MAGICNUMBER){
        my_errno = MYBADFREEPTR;
    }
    else{
        //if free list empty
        if(free_list_begin() == NULL){
            //create new head for the free list
            FreeListNode node = (FreeListNode)ptr;
            node->size = *((uint32_t*)ptr);
            node->flink = NULL;
        }
        else{
            FreeListNode current_node = free_list_begin();
            //traverse linked list
            while(current_node->flink != NULL){
                current_node = current_node->flink;
            }
            //create new node here:
            FreeListNode next_node = (FreeListNode)ptr;
            current_node->flink = next_node;
            next_node->size = *((uint32_t*)ptr);
            next_node->flink = NULL;
        }
    }
}

FreeListNode free_list_begin(){
    return first_node;
}

void coalesce_free_list(){
    FreeListNode head = free_list_begin();
    //traverse linked list
    while(head->flink != NULL){
        //test if nodes are adjacent
        if((char*)head + head->size == (char*)(head->flink)){
            //merge the two nodes together
            FreeListNode next = head->flink;
            uint32_t new_size = head->size + next->size;
            head->size = new_size;
            head->flink = next->flink;
        }
        head = head->flink;
    }
}