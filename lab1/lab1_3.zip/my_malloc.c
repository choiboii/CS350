//
//  my_malloc.c
//  Lab1: Malloc
//

#include "my_malloc.h"
#include <unistd.h>

MyErrorNo my_errno=MYNOERROR;
static int MAGICNUMBER = 123456;
FreeListNode first_node;


FreeListNode free_list_begin(){
    return first_node;
}

void insert_node(FreeListNode node){
    FreeListNode head = free_list_begin();
    
    //if the node being inserted is less than the first node
    if((uint32_t*)node < (uint32_t*)head){
        node->flink = head;
        first_node = node;
    }
    //traverse the list and insert the node where needed
    else{
        while(head->flink != NULL && (uint32_t*)(head->flink) < (uint32_t*)node){
            head = head->flink;
        }
        node->flink = head->flink;
        head->flink = node;
    }
}

void *my_malloc(uint32_t size){
    static uint32_t * free_heap_begin;
    uint32_t * ptr = free_heap_begin;
    uint32_t * heap_end = sbrk(0);

    size += 8;  //bytes for bookkeeping;
    if(size % 8 != 0){ //make chunk size divisble by 8
        size += (8 - size % 8);
    }

    uint32_t minimum_chunk_size = 16; //set minimum chunk size
    if(size > 16){
        minimum_chunk_size = size;
    }
    
    //find chunk from free list
    FreeListNode free_chunk_ptr = free_list_begin();

    //if freelist null -> call sbrk
    if(free_chunk_ptr == NULL){
        if((char*)free_heap_begin + size > (char*)heap_end){
            if(size > 8192){
                sbrk(size);
            }
            else{
                sbrk(8192);
            }
        }
        free_heap_begin += size;
    }
    else{
        uint32_t usable_chunk = 1;

        //check the first node
        if(free_chunk_ptr->size >= size){
            usable_chunk = 0;
            ptr = (uint32_t*)free_chunk_ptr;
        }
        //traverse free list to find usable chunk
        while(free_chunk_ptr->flink != NULL && usable_chunk == 1){
            if(free_chunk_ptr->size >= size){
                usable_chunk = 0;
                ptr = (uint32_t*)free_chunk_ptr;
                break;
            }
            free_chunk_ptr = free_chunk_ptr->flink;
        }
        //if no usable chunks found, create new chunk at end of heap
        if(usable_chunk == 1){
            if((char*)free_heap_begin + size > (char*)heap_end){
                if(size > 8192){
                    sbrk(size);
                }
                else{
                    sbrk(8192);
                }
            }
            free_heap_begin += size;
        }
    }

    //oversized chunk: if chunk can be halved, put remainder into free list
    if(size / 2 > minimum_chunk_size){
        //split chunk
        size = size / 2;

        FreeListNode split_chunk = (FreeListNode)free_heap_begin;
        split_chunk->size = size;
        split_chunk->flink = NULL;

        insert_node(split_chunk);
    }

    //if chunk_begin is still null:
    if(ptr == NULL){
        my_errno = MYENOMEM;
        return NULL;
    }

    //initialize bookkeeping variables in the header
    *ptr = size;
    *(ptr + 1) = MAGICNUMBER; //MAGICNUMBER indicates that the chunk is malloc'd

    return ptr + 2;
}
      
void my_free(void *ptr){
    //check if chunk is malloc'd
    if(ptr == NULL || *((uint32_t*)ptr + 1) != MAGICNUMBER){
        my_errno = MYBADFREEPTR;
    }
    else{
        //if free list empty
        if(free_list_begin() == NULL){
            //create new head for the free list
            FreeListNode node = (FreeListNode)ptr;
            node->size = *((uint32_t*)ptr);
            node->flink = NULL;
            first_node = node;
        }
        else{
            FreeListNode node = (FreeListNode)ptr;
            node->size = *((uint32_t*)ptr);
            node->flink = NULL;
            insert_node(node);
        }
    }
}

void coalesce_free_list(){
    FreeListNode head = free_list_begin();
    //traverse linked list
    while(head->flink != NULL){
        //test if nodes are adjacent
        if((uint32_t*)head + head->size + 1 == (uint32_t*)(head->flink)){
            //merge the two nodes together
            FreeListNode next = head->flink;
            uint32_t new_size = head->size + next->size;
            head->size = new_size;
            head->flink = next->flink;
            next = NULL;
        }
        head = head->flink;
    }
}